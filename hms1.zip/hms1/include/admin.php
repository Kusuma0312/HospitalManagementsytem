<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin login page</title>
</head>
<body>
    <?php
    include("include\header.php");
    ?>
</body>
</html>